
class Vehiculo:
    Color = 'Rojo'
    Ruedas= 4
    Puertas=5


class Coche(Vehiculo):

    Velocidad = 0
    Cilindrada= 8



sedan = Coche()

print(sedan.Velocidad)





